# Página de Posts

Segundo parcial práctico de tecnologías web, una página que muestra posts.

## Cómo correr el servidor

Para iniciar el servidor corre en bash

```bash
ng serve
```

Una vez corriendo el servidor, diríjase a `http://localhost:4200/`. La aplicación le redireccionará a la ruta `http://localhost:4200/parcial2` donde está el contenido.

### Hecho por

- Juan Caballero
- Julio Escobar
